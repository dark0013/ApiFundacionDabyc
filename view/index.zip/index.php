<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>prueba apis</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>

<body>

  <div class="container my-5 text-center">
    <button class="btn btn-danger w-100" onclick="traer()">Obtener</button>
    <div class="mt-5">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Nombre</th>
            <th scope="col">Email</th>
            <th scope="col">Estado</th>
          </tr>
        </thead>
        <tbody id="contenido">

        </tbody>
      </table>
    </div>
  </div>

  <script>
    var contenido = document.querySelector('#contenido')

    function traer() {
      fetch('http://localhost/apilis/models/pacientes?page=1')
        .then(res => res.json())
        .then(datos => {
          // console.log(datos)
          tabla(datos)
        })
    }

    function tabla(datos) {
      // console.log(datos)
      contenido.innerHTML = ''
      for (let valor of datos) {
        // console.log(valor.nombre)
        contenido.innerHTML += `
                
                <tr>
                    <th scope="row">${ valor.id_catalogo_producto }</th>
                    <td>${ valor.ruta }</td>
                    <td>${ valor.id_siete_lineas }</td>
                </tr>
                
                `
      }
    }
  </script>

</body>

</html>